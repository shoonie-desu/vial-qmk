/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#include "config_common.h"

#define ENCODERS_PAD_A { C1 }
#define ENCODERS_PAD_B { C2 }

/* This file is empty and unrequired */
